package com.web.microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
